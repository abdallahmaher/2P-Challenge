


import static org.testng.Assert.assertTrue;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class challenge {

	public static void main(String[] args) throws InterruptedException  {
		
		
		//Driver manager to manage the webdriver
		WebDriverManager.chromedriver().setup();
		WebDriver driver =  new ChromeDriver();	
		driver.manage().window().maximize();
		
		//go to the URL
		driver.get("http://www.way2automation.com/protractor-angularjs-practice-website.html");
		
		//click on bank icon to redirect to bank managment page
		//Scenario (1)
		String Parenttab = driver.getWindowHandle();
		driver.findElement(By.xpath("//img[@alt='banking']")).click();

		Thread.sleep(3000);
		
		for(String childtab:driver.getWindowHandles())
		{
			driver.switchTo().window(childtab);
		}
		
		Thread.sleep(3000);
		
		//go to bank manager login page 
		driver.findElement(By.xpath("//button[@ng-click='manager()']")).click();

		Thread.sleep(1000);
		
		//add customer 
		driver.findElement(By.xpath("//button[@ng-class='btnClass1']")).click();
		
		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@ng-model='fName']"))
			.sendKeys("Abdallah");
		driver.findElement(By.xpath("//input[@ng-model='lName']"))
			.sendKeys("Maher");
		driver.findElement(By.xpath("//input[@ng-model='postCd']"))
			.sendKeys("11211");
		driver.findElement(By.xpath("//button[@type='submit']"))
			.click();
		
		//get customer id from alert and close it 
		//assert alert customer id is matched
		Alert addCustomer = driver.switchTo().alert();
		String expectResult = "Customer added successfully with customer id :6";
		boolean actualResult = addCustomer.getText().equals(expectResult);
		Thread.sleep(2000);
		addCustomer.accept();
		System.out.println(actualResult);
		
		//go to customers section
		driver.findElement(By.xpath("//button[@ng-class='btnClass3']")).click();
		Thread.sleep(1000);
		
		//Assert that the user details are precisely the same as entered in the form
		driver.findElement(By.xpath("//td[contains(text(),'Abdallah')]")).isDisplayed();
		driver.findElement(By.xpath("//td[contains(text(),'Maher')]/following-sibling::td[1]")).isDisplayed();
		driver.findElement(By.xpath("//td[contains(text(),'11211')]/following-sibling::td[2]")).isDisplayed();

		
		
		//Scenario 2
		driver.findElement(By.xpath("//button[@ng-class='btnClass2']")).click();
		Thread.sleep(2000);
 
		WebElement customerList = driver.findElement(By.id("userSelect"));
		Select listOption = new Select(customerList);
		listOption.selectByValue("6");
		WebElement currencyList = driver.findElement(By.id("currency"));
		Select listOption2 = new Select(currencyList);
		listOption2.selectByValue("Dollar");
		driver.findElement(By.xpath("//button[@type='submit']")).click();

		//get account number from alert and close it 
		//Assert that the Account Number retrieved from the alert is displayed in its cell for the created customer
		Alert accountNumber = driver.switchTo().alert();
		String expectResult2 = "Account created successfully with account Number :1016";
		boolean actualResult2 = accountNumber.getText().equals(expectResult2);
		Thread.sleep(2000);
		accountNumber.accept();
		System.out.println(actualResult2);
		//go to customers again
		driver.findElement(By.xpath("//button[@ng-class='btnClass3']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[2]/div/div/table/tbody/tr[6]/td[4]")).isDisplayed();
		
		//Scenario 3
		
		//Delete the created customer in the first scenario
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[2]/div/div/table/tbody/tr[6]/td[5]/button")).click();
		Thread.sleep(2000);
		

		//driver.close();

	}
}
